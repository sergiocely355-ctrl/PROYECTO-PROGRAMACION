REGISTRO DE ACTIVIDAD DEL PROGRAMA
===================================

En esta carpeta se guarda el archivo sistema.log. El programa lo crea
cuando se ejecuta y va agregando información mientras se realizan
operaciones.

Por ejemplo, allí pueden quedar anotados el registro de un cliente,
la creación de un servicio, una reserva o algún error que se presente.
Cada registro incluye la fecha y la hora para que sea más fácil revisar
en qué momento ocurrió.

Este archivo sirve como historial de lo que pasó durante la ejecución.
No reemplaza una base de datos ni guarda los objetos para volver a
cargarlos cuando se abre el programa.
